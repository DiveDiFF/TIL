export interface Token {
  token: string;
}
