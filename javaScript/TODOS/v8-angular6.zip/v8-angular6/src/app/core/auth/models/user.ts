export interface User {
  userid: string;
  password: string;
  admin?: boolean;
}
