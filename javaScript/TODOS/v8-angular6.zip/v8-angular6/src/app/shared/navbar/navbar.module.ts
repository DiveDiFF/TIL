import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

// https://valor-software.com/ngx-bootstrap/
// Navigation bar : Collapse/ Dropdowns
import { CollapseModule } from 'ngx-bootstrap/collapse';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';

import { NavbarComponent } from './components/navbar.component';

@NgModule({
  imports: [
    CommonModule,
    CollapseModule.forRoot(),
    BsDropdownModule.forRoot(),
    RouterModule],
  declarations: [NavbarComponent],
  providers: [],
  exports: [NavbarComponent]
})
export class NavbarModule { }
