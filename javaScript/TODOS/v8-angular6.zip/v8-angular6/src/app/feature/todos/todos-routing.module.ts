import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { TodoContainerComponent } from './components';
import { AuthGuard } from '../../core';

const routes: Routes = [
  // { path: 'todos', component: TodoContainerComponent }
  { path: 'todos', component: TodoContainerComponent, canActivate: [AuthGuard] }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class TodosRoutingModule { }
