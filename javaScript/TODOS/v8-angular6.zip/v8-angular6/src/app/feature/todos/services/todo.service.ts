import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { Todo } from '../models/todo';
import { environment } from '../../../../environments/environment';
import { AuthService } from '../../../core';

@Injectable()
export class TodoService {
  todos: Todo[];
  URL = `${environment.apiUrl}/todos`;

  constructor(
    private http: HttpClient,
    private auth: AuthService) {
    this.getTodos();
  }

  getTodos() {
    const headers = this.getAuthorizationHeader();

    this.http.get<Todo[]>(this.URL, { headers })
      .subscribe(todos => this.todos = todos);
  }

  addTodo(content: string) {
    const newTodo = { id: this.lastTodoId(), content, completed: false };
    const headers = this.getAuthorizationHeader();

    this.http.post(this.URL, newTodo, { headers })
      .subscribe(() => this.todos = [newTodo, ...this.todos]);
  }

  removeTodo(id: number) {
    const headers = this.getAuthorizationHeader();

    this.http.delete(`${this.URL}/${id}`, { headers, responseType: 'text' } )
      .subscribe(() => this.todos = this.todos.filter(todo => todo.id !== id));
  }

  toggleComplete(id: number) {
    const { completed } = this.todos.find(todo => todo.id === id);
    const payload = { completed: !completed };
    const headers = this.getAuthorizationHeader();

    this.http.patch(`${this.URL}/${id}`, payload, { headers, responseType: 'text' })
      .subscribe(() => this.todos = this.todos.map(todo => {
        return todo.id === id ? Object.assign(todo, { completed: !completed }) : todo;
      }));
  }

  toggleAllTodo(completed: boolean) {
    const headers = this.getAuthorizationHeader();

    this.http.patch(`${this.URL}`, { completed }, { headers, responseType: 'text' })
      .subscribe(() => this.todos = this.todos.map(todo => {
        return Object.assign(todo, { completed });
      }));
  }

  removeCompletedTodos() {
    const headers = this.getAuthorizationHeader();

    this.http.delete(`${this.URL}/completed`, { headers, responseType: 'text' })
      .subscribe(() => this.todos = this.todos.filter(todo => !todo.completed));
  }

  private lastTodoId(): number {
    return this.todos.length ? Math.max(...this.todos.map(({ id }) => id)) + 1 : 1;
  }

  private getAuthorizationHeader(): HttpHeaders|null {
    if (this.auth.getToken()) {
      return new HttpHeaders().set('Authorization', this.auth.getToken());
      // return new HttpHeaders().set('Authorization', `Token ${this.auth.getToken()}`);
    }

    console.log('[TODO SERVICE] token is null');
    return null;
  }
}
