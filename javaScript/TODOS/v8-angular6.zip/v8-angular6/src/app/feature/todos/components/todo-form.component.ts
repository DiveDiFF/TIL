import { Component } from '@angular/core';

import { TodoService } from '../services/todo.service';

@Component({
  selector: 'todo-form',
  template: `
    <input class="form-control input-lg"
      placeholder="What needs to be done?"
      autofocus
      [(ngModel)]="content"
      (keyup.enter)="onEnter()">
  `,
  styles: [`
    .form-control {
      box-shadow: none;
      border-color: #e7ecee;
    }

    .form-control:focus {
      border-color: #23b7e5;
    }
  `]
})
export class TodoFormComponent {
  content: string;

  constructor(public todoService: TodoService) { }

  onEnter() {
    if (this.content) {
      this.todoService.addTodo(this.content);
      this.content = '';
    }
  }
}
