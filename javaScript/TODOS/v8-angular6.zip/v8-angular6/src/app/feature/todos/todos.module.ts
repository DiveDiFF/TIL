import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { NavbarModule } from './../../shared/navbar/navbar.module';

import { TodosRoutingModule } from './todos-routing.module';

import {
  TodoContainerComponent,
  TodoFormComponent,
  TodoNavComponent,
  TodoListComponent,
  TodoFooterComponent
 } from './components';

import { TodoFilterPipe } from './pipes';

import { TodoService } from './services/todo.service';


@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    NavbarModule,
    TodosRoutingModule
  ],
  declarations: [
    TodoContainerComponent,
    TodoFormComponent,
    TodoNavComponent,
    TodoListComponent,
    TodoFooterComponent,
    TodoFilterPipe
  ],
  providers: [TodoService],
  exports: [TodoContainerComponent]
})
export class TodosModule { }
