import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'todo-nav',
  template: `
    <ul class="nav nav-xs nav-pills">
      <li *ngFor="let navItem of navItems"
        [class.active]="navItem===statusNav">
        <a (click)="changeCurrentNav.emit(navItem)">{{navItem}}</a>
      </li>
    </ul>
  `,
  styles: [`
    .nav {
      margin: 15px;
    }

    .nav.nav-xs>li>a {
      padding: 4px 10px;
    }

    .nav-pills>li.active>a {
      color: #fff !important;
      background-color: #23b7e5;
    }

    .nav-pills>li.active>a:active,
    .nav-pills>li.active>a:focus,
    .nav-pills>li.active>a:hover {
      background-color: #19a9d5;
    }

    .nav>li {
      cursor: pointer;
    }
  `]
})
export class TodoNavComponent {
  @Input() navItems: string[];
  @Input() statusNav: string;
  @Output() changeCurrentNav = new EventEmitter();
}
