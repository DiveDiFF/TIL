import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';

// Features
import { SigninModule } from './feature/signin/signin.module';
import { TodosModule } from './feature/todos/todos.module';

// Core
import { AuthModule } from './core/auth/auth.module';

// Root component
import { AppComponent } from './app.component';

@NgModule({
  declarations: [ AppComponent ],
  imports: [
    BrowserModule,
    HttpClientModule,
    TodosModule,  // Feature
    SigninModule, // Feature
    AuthModule,   // Core
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
