export const environment = {
  production: true,
  apiUrl: '',
  tokenName: 'access_token',
  facebookAppId: '2017828095162490',
  googleAppId: '392106359188-c0us8css6r0alobq8jst5dps2arb2gda.apps.googleusercontent.com',
  kakaoAppId: 'ccfd936cf200b5e71b89b9a20c32073c'
};
