export const environment = {
  production: true,
  apiUrl: '/todos'
};
