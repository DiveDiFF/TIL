const router = require('express').Router();
const User = require('../models/user');

const path = require('path');
const multer = require('multer');
const fs = require('fs');

// File upload
const upload = multer({
  limits: { fileSize: 5 * 1024 * 1024 },
  storage: multer.diskStorage({
    destination(req, file, cb) {
      cb(null, 'avatars/');
    },
    filename(req, file, cb) {
      // cb(null, new Date().valueOf() + path.extname(file.originalname));
      cb(null, req.decodedToken.userid + path.extname(file.originalname));
    }
  })
});

/*
  모든 사용자 검색

  GET /users
  JWT Token / admin
*/
router.get('/', (req, res) => {
  console.log('[GET /users]', req.decodedToken);

  // if (!req.decodedToken.admin) {
  //   return res.status(403).send({ success: false, error: 'admin이 아닙니다.' });
  // }
  if (!req.decodedToken) {
    return res.status(403).send({ success: false, error: '토큰이 없습니다.' });
  }
  User.findAll().then(users => res.json(users));
});

/*
  admin 권한 부여

  PATCH /users/admin/:userid
  JWT Token / admin
*/
router.patch('/admin/:userid', (req, res) => {
  if (!req.decodedToken.admin) {
    return res.status(403).send({ error: 'admin이 아닙니다.' });
  }
  // userid에 의한 user 검색
  User.findOneByUserid(req.params.userid)
    .then(user => user.assignAdmin())
    .then(user => res.send(user));
});


router.post('/upload', upload.single('avatar'), (req, res) => {
  console.log('UPLOAD', req.file);

  // FormData => Base64
  // console.log(Buffer.from(fs.readFileSync(req.file.path)).toString('base64'));
  // Save to DB!
  const base64Image = 'data:' + req.file.mimetype + ';base64,' + Buffer.from(fs.readFileSync(req.file.path)).toString('base64');
  res.json({ file: base64Image });
  // res.json({ success: true, file: Buffer.from(fs.readFileSync(req.file.path)).toString('base64') });
});

module.exports = router;
